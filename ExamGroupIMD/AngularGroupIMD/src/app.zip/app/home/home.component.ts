import { Component } from '@angular/core';

@Component({
  selector: 'home-root',
  templateUrl: './home.component.html'
  //styleUrls: ['./app.component.css']
})
export class HomeComponent {
    pageTitle = 'GroupIMD';
}