export interface IShowReel {
    Id: number;
    Name: string;
    VideoStandard: string;
    VideoDefinition: string;
    Duration: string;
}