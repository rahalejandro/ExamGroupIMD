import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';

import { ShowReelListComponent } from './showreel-list.component';
import { SharedModule } from '../shared/shared.module';

@NgModule({
    imports: [
        RouterModule.forChild([
            { path: 'showreels', component: ShowReelListComponent }
        ]),
        SharedModule
    ],
    declarations: [
        ShowReelListComponent
    ]
})

export class ShowReelModule {
    
}